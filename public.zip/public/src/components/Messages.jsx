import React from 'react'
import styled from 'styled-components'

function Messages() {
  return (
    <Container>

    </Container>
  )
}
const Container=styled.div`
height:80%;
`
export default Messages
